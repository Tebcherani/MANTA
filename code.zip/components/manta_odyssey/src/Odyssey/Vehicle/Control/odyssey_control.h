#ifndef ODYSSEY_CONTROL_H
#define ODYSSEY_CONTROL_H

#include "odyssey_behaviors.h"

int update_odyssey_control(double, double);

#endif /* ODYSSEY_CONTROL_H */